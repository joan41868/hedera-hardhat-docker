--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.15
-- Dumped by pg_dump version 12.7 (Ubuntu 12.7-0ubuntu0.20.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE fcfs;
--
-- Name: fcfs; Type: DATABASE; Schema: -; Owner: swirlds
--

CREATE DATABASE fcfs WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE fcfs OWNER TO swirlds;

\connect fcfs

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: crypto; Type: SCHEMA; Schema: -; Owner: swirlds
--

CREATE SCHEMA crypto;


ALTER SCHEMA crypto OWNER TO swirlds;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA crypto;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: bs_blob_append(bigint, bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_append(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	newContent      bytea;
	deleteErrorCode int;
	deleteErrorSrc  int[];
	deleteErrorCtx  int;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_append()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	-- 	select (obj.content || pBytes) from binary_objects as obj where obj.id = pId for share into newContent;
--
-- 	if newContent is null then
-- 		pErrorCode := bsx_error_code_not_found();
-- 		pErrorCtx := bsx_error_ctx_identifier();
-- 		return;
-- 	end if;
--
-- 	select sto.pId, sto.pHash
-- 	from bs_blob_store(newContent) as sto into pNewId, pHash;
--
-- 	select del.pErrorCode, del.pErrorSrc, del.pErrorCtx
-- 	from bs_blob_delete(pId) as del into deleteErrorCode, deleteErrorSrc, deleteErrorCtx;

-- 	if deleteErrorCode != bsx_error_code_success_exists() then
-- 		pErrorCode := deleteErrorCode;
-- 		pErrorSrc := deleteErrorSrc;
-- 		pErrorCtx := deleteErrorCtx;
-- 		return;
-- 	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_append(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_delete(bigint); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_delete(pid bigint, OUT pdeleted boolean, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	currentRefCount bigint;
	currentId       bigint;
-- 	current         int;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_delete()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	pDeleted := false;

	select id, ref_count from binary_objects where id = pId into currentId, currentRefCount;

	if currentId is null or currentId <= 0 then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

	if currentRefCount <= 1 then
		delete from binary_objects where id = pId returning id, file_oid into currentId, pOid;
		pDeleted := true;
	else
		update binary_objects set ref_count = ref_count - 1 where id = pId returning id, file_oid into currentId, pOid;
	end if;


	if currentId is null or currentId <= 0 then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_delete(pid bigint, OUT pdeleted boolean, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_delete_trigger(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_delete_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
	result int;
begin
	select lo_unlink(old.file_oid) into result;
	return new;
end;
$$;


ALTER FUNCTION public.bs_blob_delete_trigger() OWNER TO swirlds;

--
-- Name: bs_blob_exists(bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_exists(phash bytea) RETURNS bigint
    LANGUAGE plpgsql STABLE
    AS $$
begin
	return (select bo.id from binary_objects as bo where hash = pHash limit 1);
end;
$$;


ALTER FUNCTION public.bs_blob_exists(phash bytea) OWNER TO swirlds;

--
-- Name: bs_blob_increment_ref_count(bigint); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_increment_ref_count(pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	currentRefCount bigint;
	currentId       bigint;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_increment_ref_count()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select ref_count from binary_objects where id = pId into currentRefCount;

	if currentRefCount > 0 then
		update binary_objects set ref_count = ref_count + 1 where id = pId returning id, file_oid into currentId;
	end if;


	if currentId is null or currentId <= 0 then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_increment_ref_count(pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_lookup_id_by_hash(bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_lookup_id_by_hash(phash bytea, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_retrieve()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select obj.id from binary_objects as obj where obj.hash = pHash into pId;

	if pId is null then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_lookup_id_by_hash(phash bytea, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_restore(bigint[], bytea[]); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_restore(prefcounts bigint[], pblobhashes bytea[], OUT pids bigint[], OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	deletedObjects bigint[];
begin

	pErrorCode := bsx_error_code_success_new();
	pErrorSrc := array [bsx_error_src_blob_restore()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	if pRefCounts is null or array_length(pRefCounts, 1) <= 0 then
		pErrorCode := bsx_error_code_invalid_argument();
		pErrorCtx := bsx_error_ctx_hash_list();
		return;
	end if;

	if pBlobHashes is null or not array_length(pBlobHashes, 1) = array_length(pRefCounts, 1) then
		pErrorCode := bsx_error_code_invalid_argument();
		pErrorCtx := bsx_error_ctx_ref_counts();
		return;
	end if;

	update binary_objects as b set ref_count = 0 where not b.ref_count = 0;

	with inserts as (
		update binary_objects as b set ref_count = t.ref_count
			from unnest(pRefCounts, pBlobHashes) with ordinality as t(ref_count, hash, idx)
			where b.hash = t.hash
			returning id, t.idx
	)
	select array_agg(sorted_ids.id)
	from (
			 select ti.id
			 from inserts as ti
			 order by ti.idx) as sorted_ids
	into pIds;


	with cleanup as (
		select obj.id, obj.file_oid from binary_objects as obj where obj.ref_count = 0
	), purge as (
		select lo_unlink(cl.file_oid), cl.id
		from cleanup as cl
	)
	select array_agg(array [pg.id]::bigint[])
	from purge as pg into deletedObjects;

	delete from binary_objects where id = any(deletedObjects);

end;
$$;


ALTER FUNCTION public.bs_blob_restore(prefcounts bigint[], pblobhashes bytea[], OUT pids bigint[], OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_retrieve(bigint); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_retrieve(pid bigint, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_retrieve()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select obj.file_oid from binary_objects as obj where obj.id = pId into pOid;

	if pOid is null then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_retrieve(pid bigint, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_retrieve_by_hash(bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_retrieve_by_hash(phash bytea, OUT pbytes bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_retrieve()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	-- 	select obj.content from binary_objects as obj where obj.hash = pHash into pBytes;

-- 	if pBytes is null then
-- 		pErrorCode := bsx_error_code_not_found();
-- 		pErrorCtx := bsx_error_ctx_identifier();
-- 		return;
-- 	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_retrieve_by_hash(phash bytea, OUT pbytes bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_store(bytea, oid); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_store(phash bytea, poid oid, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	foundId      bigint;
	unlinkResult int;
	currentOid   oid;
begin

	pErrorCode := bsx_error_code_success_new();
	pErrorSrc := array [bsx_error_src_blob_store()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select bo.id, bo.file_oid from binary_objects as bo where hash = pHash into foundId, currentOid;

	if foundId is not null and foundId > 0 then
		if currentOid is not null and pOid is not null and not pOid = currentOid then
			select fx from lo_unlink(pOid) as fx into unlinkResult;
		end if;

		update binary_objects set ref_count = ref_count + 1 where id = foundId returning id into pId;
	else
		insert into binary_objects (id, ref_count, hash, file_oid)
		values (DEFAULT, 1, pHash, pOid) returning id into pId;
	end if;


end ;
$$;


ALTER FUNCTION public.bs_blob_store(phash bytea, poid oid, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_update(bigint, bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_update(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	currentId bigint;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_update()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	-- 	select obj.id from binary_objects as obj where obj.id = pId for update into currentId;
--
-- 	if currentId is null or currentId <= 0 then
-- 		pErrorCode := bsx_error_code_not_found();
-- 		pErrorCtx := bsx_error_ctx_identifier();
-- 		return;
-- 	end if;
--
-- 	select fx.pId, fx.pHash, fx.pErrorCode, fx.pErrorSrc, fx.pErrorCtx
-- 	from bs_blob_store(pBytes) as fx into pNewId, pHash, pErrorCode, pErrorSrc, pErrorCtx;
--
-- 	if pErrorCode < 0 then
-- 		return;
-- 	end if;
--
-- 	select fx.pErrorCode, fx.pErrorSrc, fx.pErrorCtx
-- 	from bs_blob_delete(pId) as fx into pErrorCode, pErrorSrc, pErrorCtx;
--
-- 	if pErrorCode < 0 then
-- 		return;
-- 	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_update(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bsx_error_code_invalid_argument(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_invalid_argument() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select -2;
$$;


ALTER FUNCTION public.bsx_error_code_invalid_argument() OWNER TO swirlds;

--
-- Name: bsx_error_code_not_found(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_not_found() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select -1;
$$;


ALTER FUNCTION public.bsx_error_code_not_found() OWNER TO swirlds;

--
-- Name: bsx_error_code_success_exists(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_success_exists() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 0;
$$;


ALTER FUNCTION public.bsx_error_code_success_exists() OWNER TO swirlds;

--
-- Name: bsx_error_code_success_new(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_success_new() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1;
$$;


ALTER FUNCTION public.bsx_error_code_success_new() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_hash_list(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_hash_list() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1026;
$$;


ALTER FUNCTION public.bsx_error_ctx_hash_list() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_identifier(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_identifier() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1025;
$$;


ALTER FUNCTION public.bsx_error_ctx_identifier() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_none(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_none() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1024;
$$;


ALTER FUNCTION public.bsx_error_ctx_none() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_ref_counts(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_ref_counts() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1027;
$$;


ALTER FUNCTION public.bsx_error_ctx_ref_counts() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_append(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_append() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4100;
$$;


ALTER FUNCTION public.bsx_error_src_blob_append() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_delete(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_delete() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4102;
$$;


ALTER FUNCTION public.bsx_error_src_blob_delete() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_increment_ref_count(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_increment_ref_count() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4104;
$$;


ALTER FUNCTION public.bsx_error_src_blob_increment_ref_count() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_restore(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_restore() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4103;
$$;


ALTER FUNCTION public.bsx_error_src_blob_restore() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_retrieve(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_retrieve() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4098;
$$;


ALTER FUNCTION public.bsx_error_src_blob_retrieve() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_store(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_store() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4099;
$$;


ALTER FUNCTION public.bsx_error_src_blob_store() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_update(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_update() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4101;
$$;


ALTER FUNCTION public.bsx_error_src_blob_update() OWNER TO swirlds;

--
-- Name: bsx_error_src_none(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_none() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4096;
$$;


ALTER FUNCTION public.bsx_error_src_none() OWNER TO swirlds;

--
-- Name: bsx_error_src_self(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_self() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4097;
$$;


ALTER FUNCTION public.bsx_error_src_self() OWNER TO swirlds;

SET default_tablespace = '';

--
-- Name: binary_objects; Type: TABLE; Schema: public; Owner: swirlds
--

CREATE TABLE public.binary_objects (
    id bigint NOT NULL,
    ref_count bigint DEFAULT 1 NOT NULL,
    hash bytea NOT NULL,
    file_oid oid NOT NULL
);


ALTER TABLE public.binary_objects OWNER TO swirlds;

--
-- Name: binary_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: swirlds
--

CREATE SEQUENCE public.binary_objects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.binary_objects_id_seq OWNER TO swirlds;

--
-- Name: binary_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swirlds
--

ALTER SEQUENCE public.binary_objects_id_seq OWNED BY public.binary_objects.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: swirlds
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO swirlds;

--
-- Name: binary_objects id; Type: DEFAULT; Schema: public; Owner: swirlds
--

ALTER TABLE ONLY public.binary_objects ALTER COLUMN id SET DEFAULT nextval('public.binary_objects_id_seq'::regclass);


--
-- Name: 16475; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16475');


ALTER LARGE OBJECT 16475 OWNER TO swirlds;

--
-- Name: 16476; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16476');


ALTER LARGE OBJECT 16476 OWNER TO swirlds;

--
-- Name: 16477; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16477');


ALTER LARGE OBJECT 16477 OWNER TO swirlds;

--
-- Name: 16478; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16478');


ALTER LARGE OBJECT 16478 OWNER TO swirlds;

--
-- Name: 16479; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16479');


ALTER LARGE OBJECT 16479 OWNER TO swirlds;

--
-- Name: 16480; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16480');


ALTER LARGE OBJECT 16480 OWNER TO swirlds;

--
-- Name: 16481; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16481');


ALTER LARGE OBJECT 16481 OWNER TO swirlds;

--
-- Name: 16483; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16483');


ALTER LARGE OBJECT 16483 OWNER TO swirlds;

--
-- Name: 16486; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16486');


ALTER LARGE OBJECT 16486 OWNER TO swirlds;

--
-- Name: 16488; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16488');


ALTER LARGE OBJECT 16488 OWNER TO swirlds;

--
-- Name: 16491; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16491');


ALTER LARGE OBJECT 16491 OWNER TO swirlds;

--
-- Name: 16493; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16493');


ALTER LARGE OBJECT 16493 OWNER TO swirlds;

--
-- Name: 16499; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16499');


ALTER LARGE OBJECT 16499 OWNER TO swirlds;

--
-- Data for Name: binary_objects; Type: TABLE DATA; Schema: public; Owner: swirlds
--

COPY public.binary_objects (id, ref_count, hash, file_oid) FROM stdin;
\.
COPY public.binary_objects (id, ref_count, hash, file_oid) FROM '$$PATH$$/3012.dat';

--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: swirlds
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
\.
COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM '$$PATH$$/3010.dat';

--
-- Name: binary_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swirlds
--

SELECT pg_catalog.setval('public.binary_objects_id_seq', 25, true);


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: -
--

\i $$PATH$$/3026.dat

--
-- Name: binary_objects binary_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: swirlds
--

ALTER TABLE ONLY public.binary_objects
    ADD CONSTRAINT binary_objects_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: swirlds
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: swirlds
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: uidx_binary_objects_hash; Type: INDEX; Schema: public; Owner: swirlds
--

CREATE UNIQUE INDEX uidx_binary_objects_hash ON public.binary_objects USING btree (hash);


--
-- Name: uidx_binary_objects_ref_count; Type: INDEX; Schema: public; Owner: swirlds
--

CREATE INDEX uidx_binary_objects_ref_count ON public.binary_objects USING btree (ref_count);


--
-- PostgreSQL database dump complete
--

